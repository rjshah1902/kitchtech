<?php

error_reporting(1);

define("HOSTNAME","localhost");

define("USERNAME","root");

define("PASSWORD","");

define("DATABASE","kitchtech");

define("PROJECT_NAME","kitchtech");

?>